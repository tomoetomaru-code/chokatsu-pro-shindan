import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: '本格！腸内タイプ診断｜くるみの腸からやせる研究所',
  description: 'Rome IV基準をもとに30問で腸内タイプを詳しく診断。膨らみ型・ためこみ型・敏感型・気まぐれ型の4タイプに分類し、あなた専用の改善アドバイスをお届けします。',
  openGraph: {
    title: '本格！腸内タイプ診断',
    description: '30問・約8分で腸内タイプを詳しく分析。あなた専用の改善プランがわかります。',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ja">
      <body className="min-h-screen bg-[#fdf8f0]">{children}</body>
    </html>
  )
}
