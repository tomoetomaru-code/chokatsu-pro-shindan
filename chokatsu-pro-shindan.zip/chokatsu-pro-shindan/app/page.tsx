'use client'

import { useState, useEffect } from 'react'

// ─── 定数 ────────────────────────────────────────────
const LINE_URL = 'https://lin.ee/XXXXXXX' // ← LINEのURLをここに入れてください
const NOTE_URL = 'https://note.com/XXXXXXX' // ← noteのURLをここに入れてください

// ─── 型定義 ───────────────────────────────────────────
type GutType = 'fukurami' | 'tamekami' | 'binkan' | 'kimagure'
type Severity = 'light' | 'medium' | 'heavy'

interface Score {
  fukurami: number  // 膨らみ型
  tamekami: number  // ためこみ型
  binkan: number    // 敏感型
  kimagure: number  // 気まぐれ型
  severity: number  // 重症度
}

interface Question {
  id: number
  category: string
  text: string
  options: {
    label: string
    scores: Partial<Score>
  }[]
}

// ─── 質問データ ───────────────────────────────────────
const QUESTIONS: Question[] = [
  // カテゴリ1: 排便パターン
  {
    id: 1,
    category: '排便パターン',
    text: '週に排便は何回くらいありますか？',
    options: [
      { label: '週に1回以下', scores: { tamekami: 4 } },
      { label: '週に2〜3回', scores: { tamekami: 2 } },
      { label: 'ほぼ毎日（1〜3回）', scores: {} },
      { label: '1日に4回以上', scores: { binkan: 2 } },
    ],
  },
  {
    id: 2,
    category: '排便パターン',
    text: '便の形状はどれに近いですか？',
    options: [
      { label: 'コロコロした硬い塊', scores: { tamekami: 4 } },
      { label: '固まりだがやや硬い', scores: { tamekami: 2 } },
      { label: '普通のやわらかさ', scores: {} },
      { label: '柔らかくどろどろ', scores: { binkan: 2 } },
      { label: '水のよう', scores: { binkan: 4 } },
    ],
  },
  {
    id: 3,
    category: '排便パターン',
    text: '排便のとき、強くいきむことがありますか？',
    options: [
      { label: 'ほぼ毎回いきむ', scores: { tamekami: 3 } },
      { label: '時々いきむ', scores: { tamekami: 1 } },
      { label: 'ほとんどいきまない', scores: {} },
    ],
  },
  {
    id: 4,
    category: '排便パターン',
    text: '排便後に「出し切れていない感じ（残便感）」がありますか？',
    options: [
      { label: 'よくある', scores: { tamekami: 2, kimagure: 1 } },
      { label: '時々ある', scores: { tamekami: 1 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 5,
    category: '排便パターン',
    text: '急にトイレに行きたくなる（我慢できない感じ）がありますか？',
    options: [
      { label: 'よくある', scores: { binkan: 3 } },
      { label: '時々ある', scores: { binkan: 1 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 6,
    category: '排便パターン',
    text: '便秘と下痢を交互に繰り返すことがありますか？',
    options: [
      { label: 'よくある', scores: { kimagure: 4 } },
      { label: '時々ある', scores: { kimagure: 2 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  // カテゴリ2: お腹の症状
  {
    id: 7,
    category: 'お腹の症状',
    text: '食後にお腹が張る（膨満感）ことがありますか？',
    options: [
      { label: 'よくある（ほぼ毎食後）', scores: { fukurami: 4 } },
      { label: '時々ある', scores: { fukurami: 2 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 8,
    category: 'お腹の症状',
    text: 'ガス（おなら）が多いと感じますか？',
    options: [
      { label: 'かなり多い', scores: { fukurami: 4 } },
      { label: '少し多い', scores: { fukurami: 2 } },
      { label: '気にならない', scores: {} },
    ],
  },
  {
    id: 9,
    category: 'お腹の症状',
    text: 'お腹の痛みや不快感はどれくらい頻繁にありますか？',
    options: [
      { label: '毎日のようにある', scores: { binkan: 4 } },
      { label: '週に数回', scores: { binkan: 2 } },
      { label: '月に数回', scores: { binkan: 1 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 10,
    category: 'お腹の症状',
    text: '夕方になるとお腹の張りが強くなりますか？',
    options: [
      { label: 'よくある', scores: { fukurami: 3 } },
      { label: '時々ある', scores: { fukurami: 1 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 11,
    category: 'お腹の症状',
    text: 'ガスが出にくく、お腹が硬くなることがありますか？',
    options: [
      { label: 'よくある', scores: { fukurami: 3 } },
      { label: '時々ある', scores: { fukurami: 1 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 12,
    category: 'お腹の症状',
    text: 'お腹の症状（痛み・張り・下痢）は排便後に楽になりますか？',
    options: [
      { label: 'はい、かなり楽になる', scores: { binkan: 1, kimagure: 1 } },
      { label: '少し楽になる', scores: { binkan: 1 } },
      { label: 'あまり変わらない', scores: {} },
    ],
  },
  // カテゴリ3: 食事との関係
  {
    id: 13,
    category: '食事との関係',
    text: '豆類・ブロッコリー・キャベツ・玉ねぎを食べると、特にお腹が張りやすいですか？',
    options: [
      { label: 'かなりそう', scores: { fukurami: 4 } },
      { label: '少しそう', scores: { fukurami: 2 } },
      { label: 'あまり気にならない', scores: {} },
    ],
  },
  {
    id: 14,
    category: '食事との関係',
    text: '牛乳・ヨーグルト・チーズを食べた後にお腹の症状が出ることがありますか？',
    options: [
      { label: 'よくある', scores: { fukurami: 2, binkan: 1 } },
      { label: '時々ある', scores: { fukurami: 1 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 15,
    category: '食事との関係',
    text: '脂っこいものを食べた後にお腹の症状が悪化しますか？',
    options: [
      { label: 'よくある', scores: { binkan: 3 } },
      { label: '時々ある', scores: { binkan: 1 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 16,
    category: '食事との関係',
    text: '1日に飲むお水・お茶の量はどれくらいですか？',
    options: [
      { label: '500ml以下（コップ2杯程度）', scores: { tamekami: 3 } },
      { label: '500〜1000ml', scores: { tamekami: 1 } },
      { label: '1000〜1500ml', scores: {} },
      { label: '1500ml以上', scores: {} },
    ],
  },
  {
    id: 17,
    category: '食事との関係',
    text: '野菜・海藻・きのこ類をよく食べていますか？',
    options: [
      { label: 'ほとんど食べない', scores: { tamekami: 1, fukurami: 1 } },
      { label: 'たまに食べる', scores: {} },
      { label: '毎日食べている', scores: {} },
    ],
  },
  // カテゴリ4: ストレス・メンタル
  {
    id: 18,
    category: 'ストレス・メンタル',
    text: 'ストレスがかかったとき、お腹の症状が悪化しますか？',
    options: [
      { label: '必ずといっていいほど悪化する', scores: { binkan: 4 } },
      { label: '時々悪化する', scores: { binkan: 2 } },
      { label: 'あまり関係ない', scores: {} },
    ],
  },
  {
    id: 19,
    category: 'ストレス・メンタル',
    text: '緊張する場面（発表・会議・試験など）でお腹が痛くなったり下痢になりますか？',
    options: [
      { label: 'よくある', scores: { binkan: 4 } },
      { label: '時々ある', scores: { binkan: 2 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 20,
    category: 'ストレス・メンタル',
    text: '睡眠の質はどうですか？',
    options: [
      { label: '寝付けない・夜中に目が覚める', scores: { binkan: 1, kimagure: 1 } },
      { label: '少し眠りが浅い', scores: {} },
      { label: 'よく眠れている', scores: {} },
    ],
  },
  {
    id: 21,
    category: 'ストレス・メンタル',
    text: '「なんとなくだるい」「疲れが取れない」と感じることがありますか？',
    options: [
      { label: 'ほぼ毎日感じる', scores: { kimagure: 1, binkan: 1 } },
      { label: '時々感じる', scores: {} },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  {
    id: 22,
    category: 'ストレス・メンタル',
    text: '気分の浮き沈みが激しいと感じますか？',
    options: [
      { label: 'よくある', scores: { binkan: 2 } },
      { label: '時々ある', scores: { binkan: 1 } },
      { label: 'ほとんどない', scores: {} },
    ],
  },
  // カテゴリ5: 生活習慣
  {
    id: 23,
    category: '生活習慣',
    text: '運動習慣はありますか？',
    options: [
      { label: 'ほぼしていない', scores: { tamekami: 2 } },
      { label: '週に1〜2回', scores: { tamekami: 1 } },
      { label: '週に3回以上', scores: {} },
    ],
  },
  {
    id: 24,
    category: '生活習慣',
    text: 'デスクワークなど、座っている時間は長いですか？',
    options: [
      { label: '1日8時間以上', scores: { tamekami: 2 } },
      { label: '1日4〜8時間', scores: { tamekami: 1 } },
      { label: '1日4時間未満', scores: {} },
    ],
  },
  {
    id: 25,
    category: '生活習慣',
    text: '朝食はしっかり食べていますか？',
    options: [
      { label: 'ほぼ食べない', scores: { tamekami: 2 } },
      { label: '軽く食べる', scores: {} },
      { label: 'しっかり食べる', scores: {} },
    ],
  },
  {
    id: 26,
    category: '生活習慣',
    text: '就寝時間は規則的ですか？',
    options: [
      { label: 'かなりバラバラ', scores: { kimagure: 2 } },
      { label: '少し不規則', scores: { kimagure: 1 } },
      { label: 'ほぼ規則的', scores: {} },
    ],
  },
  // カテゴリ6: 現在の状況
  {
    id: 27,
    category: '現在の状況',
    text: 'お腹の症状はいつ頃から続いていますか？',
    options: [
      { label: '1年以上', scores: { severity: 3 } },
      { label: '半年〜1年', scores: { severity: 2 } },
      { label: '3〜6ヶ月', scores: { severity: 1 } },
      { label: '3ヶ月未満', scores: {} },
    ],
  },
  {
    id: 28,
    category: '現在の状況',
    text: 'お腹の症状が原因で、外出や仕事に影響が出ていますか？',
    options: [
      { label: 'かなり影響している', scores: { severity: 3 } },
      { label: '少し影響している', scores: { severity: 2 } },
      { label: 'あまり影響していない', scores: { severity: 1 } },
      { label: 'まったく影響していない', scores: {} },
    ],
  },
  {
    id: 29,
    category: '現在の状況',
    text: '肌荒れ（ニキビ・くすみ・乾燥）が気になりますか？',
    options: [
      { label: 'かなり気になる', scores: { fukurami: 1, kimagure: 1 } },
      { label: '少し気になる', scores: {} },
      { label: '気にならない', scores: {} },
    ],
  },
  {
    id: 30,
    category: '現在の状況',
    text: '腸活で最も改善したいことは何ですか？',
    options: [
      { label: 'お腹の張り・ガスの不快感', scores: { fukurami: 1 } },
      { label: '便秘の解消', scores: { tamekami: 1 } },
      { label: '下痢・腹痛の改善', scores: { binkan: 1 } },
      { label: '体重管理・ダイエット', scores: {} },
      { label: '肌・美容', scores: {} },
      { label: '疲れ・メンタルの改善', scores: { kimagure: 1 } },
    ],
  },
]

// ─── タイプ情報 ───────────────────────────────────────
const TYPE_INFO = {
  fukurami: {
    name: '膨らみ型',
    emoji: '🫧',
    color: 'from-purple-100 to-purple-50',
    badge: 'bg-purple-100 text-purple-800 border-purple-200',
    accent: 'text-purple-700',
    border: 'border-purple-300',
    icon: '💨',
    subtitle: 'ガス・お腹の張りが強いタイプ',
    description:
      '食後にお腹が張りやすく、ガスが多いのが特徴です。腸内でガスを産生しやすい細菌が増えていたり、特定の食品（FODMAPと呼ばれる発酵性の糖質を含む食品）に敏感になっている可能性があります。',
    mechanism:
      '腸内でFODMAPと呼ばれる短鎖炭水化物が発酵し、大量のガスを産生。腸内の善玉菌と悪玉菌のバランスが乱れることで、ガス産生菌が優位になっている状態です。消化酵素が不足している場合も同様の症状が出ます。',
    symptoms: ['食後のお腹の張り', 'おならが多い', '夕方になるほど張りが強くなる', '特定の野菜（豆・ブロッコリー）で悪化', '腸が硬くなる感じ'],
    steps: [
      {
        title: 'FODMAPを一時的に減らす',
        detail: '玉ねぎ・豆類・リンゴ・牛乳などの発酵性食品を2週間減らしてみましょう。お腹の張りが軽くなるのを感じたら、膨らみ型の改善サインです。',
      },
      {
        title: '食べ方・食べる速さを変える',
        detail: 'よく噛んで食べることで空気を飲み込む量が減り、ガスが減少します。食事は20分以上かけてゆっくり食べましょう。',
      },
      {
        title: '消化酵素の補助食品を試す',
        detail: '大根おろし・パイナップル・パパイヤには天然の消化酵素が含まれています。毎食に少量加えるだけで消化をサポートできます。',
      },
    ],
    goodFoods: ['大根おろし', '生姜', 'フェンネルティー', 'ペパーミントティー', '米・じゃがいも（FODMAPが低い主食）', 'ほうれん草・かぼちゃ'],
    badFoods: ['玉ねぎ・にんにく', '豆類（大豆・ひよこ豆）', 'ブロッコリー・キャベツ', 'りんご・もも・スイカ', '牛乳・ヨーグルト（乳糖）', '小麦（大量摂取）'],
    tip: '「低FODMAPダイエット」を2週間試すだけで、多くの膨らみ型の方はお腹の張りが軽くなります。まずは玉ねぎ抜きから始めましょう。',
  },
  tamekami: {
    name: 'ためこみ型',
    emoji: '🪨',
    color: 'from-amber-100 to-amber-50',
    badge: 'bg-amber-100 text-amber-800 border-amber-200',
    accent: 'text-amber-700',
    border: 'border-amber-300',
    icon: '💧',
    subtitle: '便秘・排便困難が続くタイプ',
    description:
      '便が出にくく、硬くなりやすいのが特徴です。腸の動き（蠕動運動）が弱まっていたり、水分・食物繊維が不足していることが多いです。腸内の善玉菌が少なく、短鎖脂肪酸の産生が減っていることも原因のひとつです。',
    mechanism:
      '腸の蠕動運動が低下し、便が腸内に長くとどまることで水分が過剰に吸収されてしまいます。短鎖脂肪酸（善玉菌が食物繊維を分解して作る物質）が少なく、腸粘膜の働きも低下。座りっぱなしの生活・水分不足・食物繊維不足が重なると悪循環になります。',
    symptoms: ['週3回以下の排便', '硬くコロコロした便', '強くいきむ必要がある', '残便感がある', '朝すっきりしない', '下腹部の重さ・不快感'],
    steps: [
      {
        title: '朝起きてすぐ水を飲む',
        detail: '起床直後に常温の水を1〜2杯飲むことで、眠っていた腸が目覚めて蠕動運動が始まります。これだけで朝の排便リズムが変わり始めます。',
      },
      {
        title: '水溶性食物繊維を意識して増やす',
        detail: 'オクラ・昆布・わかめ・大麦・りんご（皮ごと）に含まれる水溶性食物繊維は、善玉菌のエサになり短鎖脂肪酸を増やします。毎食1品プラスしましょう。',
      },
      {
        title: '腸を動かす生活習慣に変える',
        detail: '食後に10分だけ歩く、腸のマッサージ（おへそを中心に時計回りにやさしくさする）を朝晩行うだけで腸の動きが活発になります。',
      },
    ],
    goodFoods: ['オクラ', '大麦・もち麦', '昆布・わかめ・めかぶ', 'りんご（皮ごと）', '納豆', 'プルーン', 'ゴボウ（水溶性が多い部分）'],
    badFoods: ['精製された白米・白パンばかりの食事', '水分不足（500ml以下/日）', '過剰な不溶性食物繊維（糠・ゴボウのみ偏食）', 'ストレス（腸の動きを止める）', '朝食を抜く生活'],
    tip: 'ためこみ型の改善の鍵は「水分＋水溶性食物繊維」のセット。どちらか一方だけでは効果が薄いのが特徴です。',
  },
  binkan: {
    name: '敏感型',
    emoji: '🌪️',
    color: 'from-rose-100 to-rose-50',
    badge: 'bg-rose-100 text-rose-800 border-rose-200',
    accent: 'text-rose-700',
    border: 'border-rose-300',
    icon: '🧠',
    subtitle: 'ストレスで腸が過敏になるタイプ',
    description:
      'ストレスや緊張でお腹が痛くなったり、下痢になりやすいのが特徴です。「脳腸相関」と呼ばれる脳と腸のつながりが非常に強く、感情の変化が腸に直接影響しやすい体質です。腸自体は悪くなくても、腸が「過敏」になってしまっている状態です。',
    mechanism:
      'ストレスがかかると脳が腸に「危険信号」を送り、腸の動きが速くなりすぎて下痢になります。これは「脳腸軸」と呼ばれる神経ネットワークを通じた反応で、セロトニン（腸で95%が作られる幸福ホルモン）の分泌異常も関係しています。腸が過敏になると小さな刺激でも強く反応してしまいます。',
    symptoms: ['ストレスでお腹が痛くなる', '緊張するとすぐトイレに行きたくなる', '急なトイレの切迫感', '腹痛・下痢が繰り返す', '朝、出かける前に腹痛', '気分の浮き沈みが大きい'],
    steps: [
      {
        title: 'ストレスケアを腸活の最優先にする',
        detail: 'ストレスを下げることが、敏感型の最も効果的な腸活です。深呼吸（4秒吸う・7秒止める・8秒吐く）を1日3回行うだけで迷走神経が活性化し、腸の過敏さが和らぎます。',
      },
      {
        title: '腸粘膜を修復する栄養を意識する',
        detail: 'グルタミン（鶏胸肉・大豆に多い）、ビタミンD（鮭・きのこ）、亜鉛（牡蠣・豆腐）は腸の粘膜を強化します。毎日の食事に少しずつ加えましょう。',
      },
      {
        title: '発酵食品は「少量・継続」から始める',
        detail: '一気に発酵食品を増やすと腸が過敏に反応することがあります。まず毎日大さじ1の味噌汁、あるいは少量の納豆から始め、1〜2週間かけて量を増やしましょう。',
      },
    ],
    goodFoods: ['鶏胸肉・ささみ（グルタミン）', '鮭・しらす（ビタミンD）', '味噌汁（1日1杯・薄め）', 'バナナ（トリプトファン→セロトニン）', '腸粘膜に優しいお粥・スープ', '少量のぬか漬け'],
    badFoods: ['カフェイン（コーヒー・紅茶の過剰摂取）', 'アルコール', '脂っこい食事', '人工甘味料（ゼロカロリー飲料）', '空腹状態が長い（腸への刺激になる）'],
    tip: '敏感型の方は「腸を休ませる」ことも大切。食事の改善より先に、まずストレス源を1つ減らすことから始めましょう。',
  },
  kimagure: {
    name: '気まぐれ型',
    emoji: '🌊',
    color: 'from-teal-100 to-teal-50',
    badge: 'bg-teal-100 text-teal-800 border-teal-200',
    accent: 'text-teal-700',
    border: 'border-teal-300',
    icon: '🌿',
    subtitle: '便秘と下痢を繰り返す複合タイプ',
    description:
      '便秘かと思えば下痢になったり、症状がコロコロ変わるのが特徴です。腸内フローラ全体の多様性が低下していることが多く、「善玉菌の種類と量」がともに不足している状態です。生活リズムの乱れや複数のストレスが重なっている場合に多くみられます。',
    mechanism:
      '腸内フローラの多様性（菌の種類の豊富さ）が低下すると、環境の変化に対する腸の「適応力」が弱まります。少しの変化（食事・睡眠・気候）で腸の動きが大きく変動し、便秘と下痢を繰り返す状態になります。腸内細菌の種類を増やすことがこのタイプの最も効果的なアプローチです。',
    symptoms: ['便秘と下痢を繰り返す', '症状が日によってバラバラ', '疲れやすく体がだるい', '肌荒れが続く', '生活リズムが乱れやすい', '食べるものによって症状が変わる'],
    steps: [
      {
        title: '「発酵食品×食物繊維」のセットで菌を増やす',
        detail: '腸内細菌の多様性を上げるには、発酵食品（菌を補う）と食物繊維（菌のエサ）を毎食組み合わせることが効果的です。味噌汁＋わかめ、納豆＋ゴボウなど、必ずセットで食べましょう。',
      },
      {
        title: '生活リズムを一定に保つ',
        detail: '起きる時間・食べる時間・寝る時間を毎日同じにするだけで、腸内時計が整い始めます。特に「起きる時間」を固定することが腸内フローラの安定に最も効果的です。',
      },
      {
        title: '食品の種類を意識して増やす',
        detail: '「1週間で30種類の食品を食べる」を意識してみましょう（スパイス・ハーブも1種類としてカウント可）。種類を増やすことで腸内細菌の多様性が上がります。',
      },
    ],
    goodFoods: ['複数の発酵食品（味噌・納豆・ぬか漬けを日替わりで）', 'きのこ類（複数種類）', '海藻類（複数種類）', 'オリーブオイル', 'ベリー類（ポリフェノール）', 'ナッツ類（少量）'],
    badFoods: ['単調な食事（同じものばかり食べる）', '不規則な食事時間', 'インスタント食品・添加物の多い食品', '過剰なアルコール', '睡眠不足'],
    tip: '気まぐれ型は「多様性」がキーワード。同じ発酵食品を毎日食べるより、いろんな種類を日替わりで食べる方が腸内フローラが豊かになります。',
  },
}

// ─── 重症度 ───────────────────────────────────────────
const SEVERITY_INFO = {
  light: {
    label: '軽度',
    color: 'text-green-600',
    bg: 'bg-green-100',
    bar: 'bg-green-500',
    width: '33%',
    message: '腸が少し疲れているサイン。今のうちに整えておくのがベストです。',
  },
  medium: {
    label: '中度',
    color: 'text-orange-600',
    bg: 'bg-orange-100',
    bar: 'bg-orange-500',
    width: '66%',
    message: '腸内環境の乱れが進んでいます。タイプに合った腸活を早めに始めましょう。',
  },
  heavy: {
    label: '重度',
    color: 'text-red-600',
    bg: 'bg-red-100',
    bar: 'bg-red-500',
    width: '100%',
    message: '腸内環境が大きく乱れています。継続的なケアが必要な状態です。',
  },
}

// ─── スコア計算 ───────────────────────────────────────
function calcResult(answers: Record<number, number>): {
  mainType: GutType
  subType: GutType | null
  severity: Severity
  scores: Score
} {
  const score: Score = { fukurami: 0, tamekami: 0, binkan: 0, kimagure: 0, severity: 0 }

  QUESTIONS.forEach((q) => {
    const answerIndex = answers[q.id]
    if (answerIndex === undefined) return
    const option = q.options[answerIndex]
    if (!option) return
    const s = option.scores
    if (s.fukurami) score.fukurami += s.fukurami
    if (s.tamekami) score.tamekami += s.tamekami
    if (s.binkan) score.binkan += s.binkan
    if (s.kimagure) score.kimagure += s.kimagure
    if (s.severity) score.severity += s.severity
  })

  // メインタイプ判定
  const typeScores: [GutType, number][] = [
    ['fukurami', score.fukurami],
    ['tamekami', score.tamekami],
    ['binkan', score.binkan],
    ['kimagure', score.kimagure],
  ]
  typeScores.sort((a, b) => b[1] - a[1])
  const mainType = typeScores[0][0]

  // サブタイプ（2位が1位の70%以上ならサブタイプあり）
  const subType =
    typeScores[1][1] >= typeScores[0][1] * 0.7 && typeScores[1][1] > 0
      ? typeScores[1][0]
      : null

  // 重症度
  let severity: Severity
  if (score.severity <= 2) severity = 'light'
  else if (score.severity <= 5) severity = 'medium'
  else severity = 'heavy'

  return { mainType, subType, severity, scores: score }
}

// ─── カテゴリ一覧 ─────────────────────────────────────
const CATEGORIES = ['排便パターン', 'お腹の症状', '食事との関係', 'ストレス・メンタル', '生活習慣', '現在の状況']

// ─── メインコンポーネント ─────────────────────────────
export default function Home() {
  const [screen, setScreen] = useState<'top' | 'quiz' | 'loading' | 'result'>('top')
  const [currentQ, setCurrentQ] = useState(0)
  const [answers, setAnswers] = useState<Record<number, number>>({})
  const [result, setResult] = useState<ReturnType<typeof calcResult> | null>(null)
  const [animating, setAnimating] = useState(false)

  const progress = Math.round((currentQ / QUESTIONS.length) * 100)
  const currentCategory = QUESTIONS[currentQ]?.category

  function handleAnswer(optionIndex: number) {
    if (animating) return
    setAnimating(true)

    const newAnswers = { ...answers, [QUESTIONS[currentQ].id]: optionIndex }
    setAnswers(newAnswers)

    setTimeout(() => {
      if (currentQ < QUESTIONS.length - 1) {
        setCurrentQ(currentQ + 1)
        setAnimating(false)
      } else {
        setScreen('loading')
        setTimeout(() => {
          setResult(calcResult(newAnswers))
          setScreen('result')
        }, 2500)
      }
    }, 300)
  }

  function handleBack() {
    if (currentQ > 0) {
      setCurrentQ(currentQ - 1)
    }
  }

  // ─── トップ画面 ───────────────────────────────────────
  if (screen === 'top') {
    return (
      <div className="min-h-screen bg-[#fdf8f0] flex flex-col items-center px-4 py-8">
        <div className="w-full max-w-lg">
          {/* ヘッダー */}
          <div className="text-center mb-8">
            <div className="inline-block bg-amber-100 text-amber-800 text-xs font-bold px-3 py-1 rounded-full border border-amber-200 mb-4">
              くるみ｜腸からやせる研究所
            </div>
            <h1 className="text-2xl font-bold text-stone-800 leading-tight mb-2">
              本格 腸内タイプ診断
            </h1>
            <p className="text-stone-500 text-sm">30問・約8分｜Rome IV基準をベースに設計</p>
          </div>

          {/* メインカード */}
          <div className="bg-white rounded-3xl shadow-sm border border-stone-100 p-6 mb-6">
            <div className="text-center mb-6">
              <div className="text-6xl mb-4">🌿</div>
              <p className="text-stone-700 text-sm leading-relaxed">
                同じ腸活をしても効く人と効かない人がいます。
                <br />
                その差は<span className="font-bold text-amber-700">腸内タイプ</span>にあります。
              </p>
            </div>

            <div className="bg-[#fdf8f0] rounded-2xl p-4 mb-6">
              <p className="text-xs font-bold text-stone-500 mb-3">📋 この診断でわかること</p>
              <ul className="space-y-2">
                {[
                  'あなたの腸内タイプ（4タイプから判定）',
                  '腸内環境の乱れの深さ（重症度）',
                  'タイプ別の今すぐできる改善3ステップ',
                  '食べるといい食品・避けた方がいい食品',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-stone-700">
                    <span className="text-amber-500 mt-0.5">✓</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid grid-cols-4 gap-2 mb-6">
              {[
                { type: 'fukurami', label: '膨らみ型', icon: '🫧' },
                { type: 'tamekami', label: 'ためこみ型', icon: '🪨' },
                { type: 'binkan', label: '敏感型', icon: '🌪️' },
                { type: 'kimagure', label: '気まぐれ型', icon: '🌊' },
              ].map((t) => (
                <div key={t.type} className="text-center bg-stone-50 rounded-xl p-2">
                  <div className="text-2xl mb-1">{t.icon}</div>
                  <p className="text-xs text-stone-600 font-medium">{t.label}</p>
                </div>
              ))}
            </div>

            <button
              onClick={() => setScreen('quiz')}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-4 px-6 rounded-2xl transition-colors text-base"
            >
              診断をはじめる →
            </button>
            <p className="text-center text-xs text-stone-400 mt-3">
              ※この診断は医療診断ではありません。症状が重い・長引く場合は医療機関にご相談ください。
            </p>
          </div>

          <div className="flex items-center gap-3 bg-amber-50 rounded-2xl p-4 border border-amber-100">
            <span className="text-2xl">🔒</span>
            <p className="text-xs text-stone-600">
              回答データは診断結果の表示のみに使用します。個人情報の収集は行いません。
            </p>
          </div>
        </div>
      </div>
    )
  }

  // ─── ローディング画面 ─────────────────────────────────
  if (screen === 'loading') {
    return (
      <div className="min-h-screen bg-[#fdf8f0] flex flex-col items-center justify-center px-4">
        <div className="text-center">
          <div className="text-6xl mb-6 animate-bounce">🔬</div>
          <h2 className="text-xl font-bold text-stone-800 mb-2">腸内タイプを分析しています</h2>
          <p className="text-stone-500 text-sm mb-8">30項目の回答をもとに判定中…</p>
          <div className="w-64 h-2 bg-stone-200 rounded-full overflow-hidden">
            <div className="h-full bg-amber-500 rounded-full animate-pulse" style={{ width: '75%' }} />
          </div>
        </div>
      </div>
    )
  }

  // ─── 質問画面 ─────────────────────────────────────────
  if (screen === 'quiz') {
    const q = QUESTIONS[currentQ]
    const categoryIndex = CATEGORIES.indexOf(currentCategory)

    return (
      <div className="min-h-screen bg-[#fdf8f0] flex flex-col px-4 py-6">
        <div className="w-full max-w-lg mx-auto">
          {/* プログレス */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                {currentCategory}
              </span>
              <span className="text-xs text-stone-500">
                {currentQ + 1} / {QUESTIONS.length}
              </span>
            </div>
            <div className="w-full h-2 bg-stone-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex mt-2 gap-1">
              {CATEGORIES.map((cat, i) => (
                <div
                  key={cat}
                  className={`flex-1 h-1 rounded-full transition-colors ${
                    i <= categoryIndex ? 'bg-amber-400' : 'bg-stone-200'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* 質問 */}
          <div
            className={`bg-white rounded-3xl shadow-sm border border-stone-100 p-6 mb-4 transition-opacity duration-300 ${
              animating ? 'opacity-0' : 'opacity-100'
            }`}
          >
            <p className="text-xs text-stone-400 mb-3">Q{q.id}</p>
            <h2 className="text-base font-bold text-stone-800 leading-relaxed mb-6">
              {q.text}
            </h2>

            <div className="space-y-3">
              {q.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => handleAnswer(i)}
                  disabled={animating}
                  className="w-full text-left bg-[#fdf8f0] hover:bg-amber-50 border border-stone-200 hover:border-amber-300 rounded-2xl p-4 transition-all text-sm text-stone-700 font-medium active:scale-98"
                >
                  <span className="inline-block w-6 h-6 rounded-full border border-stone-300 text-center text-xs leading-6 mr-2 text-stone-400">
                    {String.fromCharCode(65 + i)}
                  </span>
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* 戻るボタン */}
          {currentQ > 0 && (
            <button
              onClick={handleBack}
              className="text-sm text-stone-400 hover:text-stone-600 transition-colors"
            >
              ← 前の質問に戻る
            </button>
          )}
        </div>
      </div>
    )
  }

  // ─── 結果画面 ─────────────────────────────────────────
  if (screen === 'result' && result) {
    const { mainType, subType, severity } = result
    const main = TYPE_INFO[mainType]
    const sev = SEVERITY_INFO[severity]

    return (
      <div className="min-h-screen bg-[#fdf8f0] pb-16">
        <div className="w-full max-w-lg mx-auto px-4 pt-6">

          {/* ─ タイプ判定バナー ─ */}
          <div className={`bg-gradient-to-br ${main.color} rounded-3xl p-6 mb-4 border ${main.border}`}>
            <p className="text-xs font-bold text-stone-500 mb-1">あなたの腸内タイプは…</p>
            <div className="flex items-center gap-3 mb-3">
              <span className="text-5xl">{main.emoji}</span>
              <div>
                <h1 className={`text-3xl font-black ${main.accent}`}>{main.name}</h1>
                <p className="text-sm text-stone-600">{main.subtitle}</p>
              </div>
            </div>
            {subType && (
              <div className="bg-white/60 rounded-xl p-3">
                <p className="text-xs text-stone-600">
                  サブタイプ：<span className="font-bold">{TYPE_INFO[subType].name}</span> の傾向もあります
                </p>
              </div>
            )}
          </div>

          {/* ─ 重症度 ─ */}
          <div className="bg-white rounded-3xl border border-stone-100 shadow-sm p-5 mb-4">
            <p className="text-xs font-bold text-stone-500 mb-3">腸内環境の乱れ度</p>
            <div className="flex items-center gap-3 mb-2">
              <span className={`text-sm font-black ${sev.color} ${sev.bg} px-3 py-1 rounded-full`}>
                {sev.label}
              </span>
              <div className="flex-1 h-3 bg-stone-100 rounded-full overflow-hidden">
                <div
                  className={`h-full ${sev.bar} rounded-full transition-all duration-1000`}
                  style={{ width: sev.width }}
                />
              </div>
            </div>
            <p className="text-sm text-stone-600">{sev.message}</p>
          </div>

          {/* ─ タイプの説明 ─ */}
          <div className="bg-white rounded-3xl border border-stone-100 shadow-sm p-5 mb-4">
            <h2 className="font-bold text-stone-800 mb-3 flex items-center gap-2">
              <span>{main.emoji}</span> {main.name}とは？
            </h2>
            <p className="text-sm text-stone-700 leading-relaxed mb-4">{main.description}</p>

            <div className="bg-[#fdf8f0] rounded-2xl p-4">
              <p className="text-xs font-bold text-stone-500 mb-2">🔬 腸内で起きていること</p>
              <p className="text-sm text-stone-700 leading-relaxed">{main.mechanism}</p>
            </div>
          </div>

          {/* ─ 主な症状チェック ─ */}
          <div className="bg-white rounded-3xl border border-stone-100 shadow-sm p-5 mb-4">
            <h2 className="font-bold text-stone-800 mb-3">このタイプに多い症状</h2>
            <div className="space-y-2">
              {main.symptoms.map((s, i) => (
                <div key={i} className="flex items-center gap-2 text-sm text-stone-700">
                  <span className={`w-5 h-5 rounded-full ${main.badge} flex items-center justify-center text-xs font-bold border`}>
                    ✓
                  </span>
                  {s}
                </div>
              ))}
            </div>
          </div>

          {/* ─ 改善3ステップ ─ */}
          <div className="bg-white rounded-3xl border border-stone-100 shadow-sm p-5 mb-4">
            <h2 className="font-bold text-stone-800 mb-4">
              {main.icon} 今すぐできる改善3ステップ
            </h2>
            <div className="space-y-4">
              {main.steps.map((step, i) => (
                <div key={i} className="flex gap-3">
                  <div className={`flex-shrink-0 w-7 h-7 rounded-full ${main.badge} border flex items-center justify-center text-sm font-black`}>
                    {i + 1}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-stone-800 mb-1">{step.title}</p>
                    <p className="text-xs text-stone-600 leading-relaxed">{step.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ─ 食品ガイド ─ */}
          <div className="bg-white rounded-3xl border border-stone-100 shadow-sm p-5 mb-4">
            <h2 className="font-bold text-stone-800 mb-4">🍽️ {main.name}の食品ガイド</h2>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-green-50 rounded-2xl p-3 border border-green-100">
                <p className="text-xs font-bold text-green-700 mb-2">✅ 積極的に食べたいもの</p>
                <ul className="space-y-1">
                  {main.goodFoods.map((f, i) => (
                    <li key={i} className="text-xs text-stone-700">・{f}</li>
                  ))}
                </ul>
              </div>
              <div className="bg-red-50 rounded-2xl p-3 border border-red-100">
                <p className="text-xs font-bold text-red-700 mb-2">⚠️ 控えた方がいいもの</p>
                <ul className="space-y-1">
                  {main.badFoods.map((f, i) => (
                    <li key={i} className="text-xs text-stone-700">・{f}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* ─ くるみのひとこと ─ */}
          <div className={`bg-gradient-to-br ${main.color} rounded-3xl p-5 mb-6 border ${main.border}`}>
            <p className="text-xs font-bold text-stone-500 mb-2">💡 くるみからのひとこと</p>
            <p className="text-sm text-stone-700 leading-relaxed">{main.tip}</p>
          </div>

          {/* ─ CTAセクション ─ */}
          <div className="space-y-3 mb-8">
            <div className="bg-white rounded-3xl border-2 border-green-400 shadow-sm p-5">
              <div className="flex items-start gap-3">
                <span className="text-3xl">📩</span>
                <div className="flex-1">
                  <p className="text-xs font-bold text-stone-500 mb-1">無料プレゼント</p>
                  <p className="font-bold text-stone-800 mb-1">
                    {main.name}専用 腸活解説PDF
                  </p>
                  <p className="text-xs text-stone-600 mb-3">
                    今すぐ実践できる詳しい改善プランをPDFにまとめました。
                    LINEに登録するだけで無料で受け取れます。
                  </p>
                  <a
                    href={LINE_URL}
                    className="block w-full bg-green-500 hover:bg-green-600 text-white text-center font-bold py-3 px-4 rounded-xl transition-colors text-sm"
                  >
                    📩 LINEで無料PDF受け取る →
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-stone-100 shadow-sm p-5">
              <div className="flex items-start gap-3">
                <span className="text-3xl">📝</span>
                <div className="flex-1">
                  <p className="text-xs font-bold text-stone-500 mb-1">腸活×ダイエット 基礎note</p>
                  <p className="font-bold text-stone-800 mb-1">
                    腸活でダイエットが変わる理由
                  </p>
                  <p className="text-xs text-stone-600 mb-3">
                    なぜカロリー制限だけでは痩せられないのか。腸内フローラ・脳腸相関の仕組みをわかりやすく解説した8,000字のnoteです。
                  </p>
                  <a
                    href={NOTE_URL}
                    className="block w-full bg-stone-800 hover:bg-stone-900 text-white text-center font-bold py-3 px-4 rounded-xl transition-colors text-sm"
                  >
                    📝 noteを読む（¥2,980） →
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* ─ もう一度診断する ─ */}
          <div className="text-center mb-8">
            <button
              onClick={() => {
                setScreen('top')
                setCurrentQ(0)
                setAnswers({})
                setResult(null)
              }}
              className="text-sm text-stone-400 hover:text-stone-600 underline transition-colors"
            >
              もう一度診断する
            </button>
          </div>

          {/* 免責 */}
          <p className="text-center text-xs text-stone-400 px-4">
            ※この診断は医療診断ではありません。症状が重い・長引く場合は医療機関にご相談ください。
          </p>
        </div>
      </div>
    )
  }

  return null
}
